/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conectar;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author publico
 */
public class conexionmysql {
    Connection conectarBD= null;

    public Connection conexion() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conectarBD = DriverManager.getConnection("jdbc:mysql://127.0.0.1/bdbiblioteca", "root", "");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error de conexion de la base de datos");

        } catch (ClassNotFoundException ex) {
        }
        return conectarBD;
    
}}

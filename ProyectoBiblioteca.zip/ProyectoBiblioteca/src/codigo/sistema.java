/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigo;

import conectar.conexionmysql;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author publico
 */
public class sistema {
    String nombre,apellido,correo,password,telefono,tipo_usuario;
    /*variables del menu item añadir*/
   
    public ArrayList llenarcombo()throws SQLException, ClassNotFoundException{
        ArrayList <String> agregar= new ArrayList<>();
        try {
            
            conexionmysql conectar= new conexionmysql();
            Connection cn= conectar.conexion();
            Statement estado=cn.createStatement();
            ResultSet sentencia= estado.executeQuery("SELECT * FROM usuario");
            while(sentencia.next()){
            agregar.add(sentencia.getString("nombre"));}
            return agregar;
        } catch (SQLException ex) {
            Logger.getLogger(sistema.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
        
    }
    public int eliminar(String nom)throws SQLException, ClassNotFoundException{
            conexionmysql conectar = new conexionmysql();
            Connection cn= conectar.conexion();
            Statement estado=cn.createStatement();
            int  eliminar=estado.executeUpdate("DELETE FROM usuario WHERE nombre='"+nom+"'");
           
        return eliminar;
            
}
    public ResultSet buscar_usuario(int id){
        try {
            conexionmysql conectar = new conexionmysql();
            Connection cn= conectar.conexion();
            Statement estado=cn.createStatement();
            ResultSet buscar=estado.executeQuery("SELECT * FROM usuario WHERE id_usuario='"+id+"'");
            return buscar;
            
        } catch (SQLException ex) {
            Logger.getLogger(sistema.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
        
    }
    public boolean actualizar_usuario(String nombre,String apellido,String correo, String password,String telefono,String tipo_usuario,int id_usuario){
        try {
            boolean resultado=false;
            conexionmysql conectar=new conexionmysql();
            Connection cn= conectar.conexion();
            Statement estado=cn.createStatement();
            int sentencia= estado.executeUpdate("UPDATE usuario SET nombre='"+nombre+"',apellido='"+apellido+"',correo='"+correo+"',password='"+password+"',telefono='"+telefono+"',tipo_usuario='"+tipo_usuario+"' WHERE id_usuario="+id_usuario);
            if(sentencia>0){return  true;}
            else{return false;}
        } catch (SQLException ex) {
            Logger.getLogger(sistema.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
}

    public  boolean registrar_usuario(String nombre,String apellido,String correo, String password,String telefono,String tipo_usuario){
        try {
            boolean resultado=false;
            conexionmysql conectar=new conexionmysql();
        Connection cn=conectar.conexion();
            Statement estado=cn.createStatement();
            int sentencia= estado.executeUpdate("INSERT INTO usuario (nombre,apellido,correo,password,telefono,tipo_usuario) VALUES "+"('"+nombre+"','"+apellido+"','"+correo+"','"+password+"','"+telefono+"','"+tipo_usuario+"')");
            if(sentencia>0){resultado=true; }
            else{resultado=false;}
            return resultado;
        } catch (SQLException ex) {
            Logger.getLogger(sistema.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
        
        
    }
    /*codigo del menu items añadir*/
    public ArrayList llenarcombo_autor()throws SQLException, ClassNotFoundException{
        ArrayList <String> insertar= new ArrayList<>();
        try {
            
            conexionmysql conectar= new conexionmysql();
            Connection cn= conectar.conexion();
            Statement estado=cn.createStatement();
            ResultSet sentencia= estado.executeQuery("SELECT * FROM autor");
            while(sentencia.next()){
            insertar.add(sentencia.getString("nombre"));}
            return insertar;
        } catch (SQLException ex) {
            Logger.getLogger(sistema.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
        
    }
    public int eliminar_autor(String nom)throws SQLException, ClassNotFoundException{
            conexionmysql conectar = new conexionmysql();
            Connection cn= conectar.conexion();
            Statement estado=cn.createStatement();
            int  eliminar=estado.executeUpdate("DELETE FROM autor WHERE nombre='"+nom+"'");
           
        return eliminar;
            
}
    public ResultSet buscar_autor(int id){
        try {
            conexionmysql conectar = new conexionmysql();
            Connection cn= conectar.conexion();
            Statement estado=cn.createStatement();
            ResultSet buscar=estado.executeQuery("SELECT * FROM autor WHERE id='"+id+"'");
            return buscar;
            
        } catch (SQLException ex) {
            Logger.getLogger(sistema.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
        
    }
    public boolean actualizar_autor(String nombre,String apellido,String fechanacimento,int id_autor){
        try {
            boolean resultado=false;
            conexionmysql conectar=new conexionmysql();
            Connection cn= conectar.conexion();
            Statement estado=cn.createStatement();
            int sentencia= estado.executeUpdate("UPDATE autor SET nombre='"+nombre+"',apellido='"+apellido+"',fechaNac='"+fechanacimento+"' WHERE id="+id_autor);
            if(sentencia>0){return  true;}
            else{return false;}
        } catch (SQLException ex) {
            Logger.getLogger(sistema.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
}

    public  boolean registrar_autor(String nombre,String apellido,String fechanacimiento){
        try {
            boolean resultado=false;
            conexionmysql conectar=new conexionmysql();
        Connection cn=conectar.conexion();
            Statement estado=cn.createStatement();
            int sentencia= estado.executeUpdate("INSERT INTO autor (nombre,apellido,fechaNac) VALUES "+"('"+nombre+"','"+apellido+"','"+fechanacimiento+"')");
            if(sentencia>0){resultado=true; }
            else{resultado=false;}
            return resultado;
        } catch (SQLException ex) {
            Logger.getLogger(sistema.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
        
        
    }
    /*codigo del item editorial*/
     public ArrayList llenarcombo_editorial()throws SQLException, ClassNotFoundException{
        ArrayList <String> agregar= new ArrayList<>();
        try {
            
            conexionmysql conectar= new conexionmysql();
            Connection cn= conectar.conexion();
            Statement estado=cn.createStatement();
            ResultSet sentencia= estado.executeQuery("SELECT * FROM editorial");
            while(sentencia.next()){
            agregar.add(sentencia.getString("nombre"));}
            return agregar;
        } catch (SQLException ex) {
            Logger.getLogger(sistema.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
        
    }
    public int eliminar_editorial(String nom)throws SQLException, ClassNotFoundException{
            conexionmysql conectar = new conexionmysql();
            Connection cn= conectar.conexion();
            Statement estado=cn.createStatement();
            int  eliminar=estado.executeUpdate("DELETE FROM editorial WHERE nombre='"+nom+"'");
           
        return eliminar;
            
}
    public ResultSet buscar_editorial(int id){
        try {
            conexionmysql conectar = new conexionmysql();
            Connection cn= conectar.conexion();
            Statement estado=cn.createStatement();
            ResultSet buscar=estado.executeQuery("SELECT * FROM editorial WHERE id='"+id+"'");
            return buscar;
            
        } catch (SQLException ex) {
            Logger.getLogger(sistema.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
        
    }
    public boolean actualizar_editorial(String nombre,String pais,String ciudad,int id_editorial){
        try {
            boolean resultado=false;
            conexionmysql conectar=new conexionmysql();
            Connection cn= conectar.conexion();
            Statement estado=cn.createStatement();
            int sentencia= estado.executeUpdate("UPDATE editorial SET nombre='"+nombre+"',pais='"+pais+",ciudad='"+ciudad+"' WHERE id="+id_editorial);
            if(sentencia>0){return  true;}
            else{return false;}
        } catch (SQLException ex) {
            Logger.getLogger(sistema.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
}

    public  boolean registrar_editorial(String nombre,String pais,String ciudad){
        try {
            boolean resultado=false;
            conexionmysql conectar=new conexionmysql();
        Connection cn=conectar.conexion();
            Statement estado=cn.createStatement();
            int sentencia= estado.executeUpdate("INSERT INTO editorial (nombre,pais,ciudad) VALUES "+"('"+nombre+"','"+pais+"','"+ciudad+"')");
            if(sentencia>0){resultado=true; }
            else{resultado=false;}
            return resultado;
        } catch (SQLException ex) {
            Logger.getLogger(sistema.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
        
        
    }
    /*codigo del menu item libro*/
     public ArrayList llenarcombo_libro()throws SQLException, ClassNotFoundException{
        ArrayList <String> agregar= new ArrayList<>();
        try {
            
            conexionmysql conectar= new conexionmysql();
            Connection cn= conectar.conexion();
            Statement estado=cn.createStatement();
            ResultSet sentencia= estado.executeQuery("SELECT * FROM libro");
            while(sentencia.next()){
            agregar.add(sentencia.getString("edicion"));}
            return agregar;
        } catch (SQLException ex) {
            Logger.getLogger(sistema.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
        
    }
    public int eliminar_libro(String nom)throws SQLException, ClassNotFoundException{
            conexionmysql conectar = new conexionmysql();
            Connection cn= conectar.conexion();
            Statement estado=cn.createStatement();
            int  eliminar=estado.executeUpdate("DELETE FROM libro WHERE edicion='"+nom+"'");
           
        return eliminar;
            
}
    public ResultSet buscar_libro(int id){
        try {
            conexionmysql conectar = new conexionmysql();
            Connection cn= conectar.conexion();
            Statement estado=cn.createStatement();
            ResultSet buscar=estado.executeQuery("SELECT * FROM libro WHERE id='"+id+"'");
            return buscar;
            
        } catch (SQLException ex) {
            Logger.getLogger(sistema.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
        
    }
    public boolean actualizar_libro(String edicion,String fechaLanz,int id_libro){
        try {
            boolean resultado=false;
            conexionmysql conectar=new conexionmysql();
            Connection cn= conectar.conexion();
            Statement estado=cn.createStatement();
            int sentencia= estado.executeUpdate("UPDATE libro SET edicion='"+edicion+"',fechaLanz='"+fechaLanz+"' WHERE id="+id_libro);
            if(sentencia>0){return  true;}
            else{return false;}
        } catch (SQLException ex) {
            Logger.getLogger(sistema.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
}

    public  boolean registrar_libro(String edicion,String fechaLanz){
        try {
            boolean resultado=false;
            conexionmysql conectar=new conexionmysql();
        Connection cn=conectar.conexion();
            Statement estado=cn.createStatement();
            int sentencia= estado.executeUpdate("INSERT INTO libro (edicion,fechaLanz) VALUES "+"('"+edicion+"','"+fechaLanz+"')");
            if(sentencia>0){resultado=true; }
            else{resultado=false;}
            return resultado;
        } catch (SQLException ex) {
            Logger.getLogger(sistema.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
        
        
    }
    
    
    public sistema() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getTipo_usuario() {
        return tipo_usuario;
    }

    public void setTipo_usuario(String tipo_usuario) {
        this.tipo_usuario = tipo_usuario;
    }
    
}
